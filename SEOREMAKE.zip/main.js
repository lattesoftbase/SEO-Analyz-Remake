let text = document.querySelector("#texty");
let textLength = document.querySelector("#length");



text.addEventListener("input", () => {
    textLength.textContent = `Количество символов: ${text.value.length}`;
});